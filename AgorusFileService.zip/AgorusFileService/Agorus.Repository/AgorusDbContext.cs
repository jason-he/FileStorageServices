﻿using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Reflection.Metadata;
using Agorus.Domain;

namespace Agorus.Repository
{
    public class AgorusDbContext: DbContext
    {
        public AgorusDbContext(DbContextOptions<AgorusDbContext> options)
            : base(options)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AgorusFile>().ToTable("FileData").HasKey(_obj => new { _obj.ID });
        }

        public AgorusDbContext(string _connStr) : base(GetOptions(_connStr))
        {
        }

        private static DbContextOptions GetOptions(string connectionString)
        {
            return SqlServerDbContextOptionsExtensions.UseSqlServer(new DbContextOptionsBuilder<AgorusDbContext>(), connectionString).Options;
        }

        public DbSet<AgorusFile> AgorusFiles { get; set; }
    }
}