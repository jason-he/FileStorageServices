﻿using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Reflection.Metadata;
using Agorus.Domain;

namespace Agorus.Repository
{
    public class AgorusRepository : IAgorusRepository
    {
        private readonly List<AgorusFile> agorusFiles;
        public AgorusDbContext? _dbContext { get; set; }

        public AgorusRepository() 
        {
            _dbContext = null;
            agorusFiles = new List<AgorusFile>()
            {
                new AgorusFile()
                {
                    ID = 145,
                    FileName =  "Myfile1",
                    FileContent = new byte[]{  0x48, 0x65, 0x6C, 0x6C, 0x6F},
                    CreatedOn = DateTime.UtcNow,
                    CreatedBy = 0,
                    ModifiedOn = DateTime.UtcNow,
                    ModifiedBy = 0
                },
                new AgorusFile()
                {
                    ID = 146,
                    FileName =  "Myfile2",
                    FileContent = new byte[]{  0x48, 0x64, 0x6C, 0x6F, 0x67},
                    CreatedOn = DateTime.UtcNow,
                    CreatedBy = 0,
                    ModifiedOn = DateTime.UtcNow,
                    ModifiedBy = 0
                },
                 new AgorusFile()
                {
                    ID = 148,
                    FileName =  "Myfile3",
                    FileContent = new byte[]{  0xE8, 0x6D, 0xFC, 0x6F, 0x67},
                    CreatedOn = DateTime.UtcNow,
                    CreatedBy = 0,
                    ModifiedOn = DateTime.UtcNow,
                    ModifiedBy = 0
                }
            };
        }

        public AgorusFile GetAgorusFile(int id)
        {
            if (_dbContext != null)
            {
                var results = from agorursFile in _dbContext.AgorusFiles
                              where agorursFile.ID == id
                              select agorursFile;
                var retValue = results.FirstOrDefault();

                if (retValue != null)
                {
                    return retValue;
                }
                else
                {
                    return new AgorusFile();
                }
            }
            else
            {
                var results = from agorursFile in agorusFiles
                              where agorursFile.ID == id
                              select agorursFile;
                var retValue = results.FirstOrDefault();

                if (retValue != null)
                {
                    return retValue;
                }
                else
                {
                    return new AgorusFile();
                }
            }
        }


        public IEnumerable<AgorusFile> GetAgorusFiles()
        {
            if (_dbContext == null)
            {
                return agorusFiles;
            }

            return _dbContext.AgorusFiles.ToList();
        }

        public async Task<int> SaveAgorusFile(AgorusFile dataFile)
        {
            if (_dbContext == null) 
            {
                dataFile.ID  = agorusFiles.Max(a => a.ID) + 1;  
                agorusFiles.Add(dataFile);

                return dataFile.ID;
            }
            else
            {
                try
                {
                    _dbContext.AgorusFiles.Add(dataFile);
                    await _dbContext.SaveChangesAsync();
                }
                catch (Exception ex)
                {
                    var msg = ex.Message;
                    return 0;
                }

                return dataFile.ID;
            }
        }
    }
}