﻿using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading;
using System.Reflection.Metadata;
using Agorus.Domain;
using Microsoft.Identity.Client;

namespace Agorus.Repository
{
    public interface IAgorusRepository 
    {
        AgorusDbContext? _dbContext { get; set; }
        AgorusFile? GetAgorusFile(int id);
        IEnumerable<AgorusFile> GetAgorusFiles();
        Task<int> SaveAgorusFile(AgorusFile dataFile);
    }
}