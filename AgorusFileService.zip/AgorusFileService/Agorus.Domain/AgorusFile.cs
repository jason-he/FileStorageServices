﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Agorus.Domain
{
    [Table("fileData")]
    public class AgorusFile
    {
        public int ID { get; set; }
        public string FileName { get; set; }
        public byte[] FileContent { get; set; }
        public DateTime CreatedOn { get; set; }
        public int CreatedBy { get; set; }
        public DateTime ModifiedOn { get; set; }
        public int ModifiedBy { get; set; }

        public void CopyFileData(AgorusFile file)
        {
            this.ID = file.ID;
            this.FileName = file.FileName;
            this.FileContent = file.FileContent;
            this.CreatedOn = file.CreatedOn;
            this.CreatedBy = file.CreatedBy;
            this.ModifiedOn = file.ModifiedOn;
            this.ModifiedBy = file.ModifiedBy;
        }

        public void CopyFileData(AgorusFileContent file)
        {
            this.FileName = file.FileName;
            this.FileContent = Convert.FromBase64String(file.FileContent);
            this.CreatedOn = file.CreatedOn;
            this.CreatedBy = file.CreatedBy;
            this.ModifiedOn = file.ModifiedOn;
            this.ModifiedBy = file.ModifiedBy;
        }
    }
}