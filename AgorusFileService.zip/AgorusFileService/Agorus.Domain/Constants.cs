﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agorus.Domain
{
    public static class Constants
    {
        /// <summary>
        /// Prod application computer name
        /// </summary>
        public const string ProdComputer = "AgorusProd";
        /// <summary>
        /// Prod application DB connectionString
        /// </summary>
        public const string ProdDBConnString = "ProdDBConnString";
        /// <summary>
        /// Dev application DB connectionString
        /// </summary>
        public const string DevDBConnString = "DevDBConnString";

        public const int DefaultUser = 0;
    }
}
