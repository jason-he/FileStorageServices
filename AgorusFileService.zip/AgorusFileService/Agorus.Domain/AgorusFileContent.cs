﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Agorus.Domain
{
    public class AgorusFileContent
    {
        public int? ID { get; set; }
        public string FileName { get; set; }
        public string FileContent { get; set; }
        public DateTime CreatedOn { get; set; }
        public int CreatedBy { get; set; }
        public DateTime ModifiedOn { get; set; }
        public int ModifiedBy { get; set; }

        public void CopyFileData(AgorusFile? file)
        {
            if (file != null)
            {
                this.FileName = file.FileName;
                this.FileContent = Convert.ToBase64String(file.FileContent);
                this.CreatedOn = file.CreatedOn;
                this.CreatedBy = file.CreatedBy;
                this.ModifiedOn = file.ModifiedOn;
                this.ModifiedBy = file.ModifiedBy;
            }
        }
    }
}