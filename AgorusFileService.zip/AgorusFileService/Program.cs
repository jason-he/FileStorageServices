using System;
using Microsoft.AspNetCore.Authentication.Negotiate;
using Microsoft.EntityFrameworkCore;
using Agorus.Repository;
using Agorus.Domain;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddAuthentication(NegotiateDefaults.AuthenticationScheme)
   .AddNegotiate();

builder.Services.AddAuthorization(options =>
{
    // By default, all incoming requests will be authorized according to the default policy.
    options.FallbackPolicy = options.DefaultPolicy;
});

var machineName = Environment.MachineName;
var envName = string.Empty;
var connectionStringKey = string.Empty;
if (machineName.ToLower().Contains(Constants.ProdComputer.ToLower()))
{
    envName = $"appsettings.Production.json";
    connectionStringKey = Constants.ProdDBConnString;
}
else
{
    envName = $"appsettings.Development.json";
    connectionStringKey = Constants.DevDBConnString;
}

builder.Host.ConfigureAppConfiguration((hostingContext, config) =>
{
    // Add application settings and enviroment settings.
    config.AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
    .AddJsonFile(envName, optional: true, reloadOnChange: true);

    var connectionString = hostingContext.Configuration.GetSection("ConnectionStrings")[connectionStringKey];
    // Add DB context.
    builder.Services.AddDbContext<AgorusDbContext>(opt => opt.UseSqlServer(connectionString));
});

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();
