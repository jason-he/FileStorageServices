﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Agorus.Repository;
using Agorus.Domain;
using System.Linq;

namespace AgorusFileService.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class FileManagerController: ControllerBase
    {
        private readonly AgorusDbContext? _dbContext;
        private readonly ILogger<FileManagerController>? _logger;
        private IAgorusRepository _services;

        public FileManagerController(ILogger<FileManagerController>? logger, AgorusDbContext? dbContext)
        {
            _dbContext = dbContext;
            _logger = logger;
            _services = new AgorusRepository();
            _services._dbContext = _dbContext;
        }

        [HttpGet(Name = "GetAgorusFiles")]
        /// <summary>
        /// This API method is to get all binary files.
        /// </summary>
        /// <param>None</param>
        public IEnumerable<AgorusFile> Get()
        {
            return _services.GetAgorusFiles();
        }

        [HttpPost]
        /// <summary>
        /// This API method is to create a new record for a binary file.
        /// </summary>
        /// <param>None</param>
        public async Task<int> CreateAgorusFile(AgorusFileContent fileData)
        {
            if (fileData == null || fileData.FileContent == null || fileData.FileContent.Length == 0)
            {
                return 0;
            }

            if (fileData.CreatedBy < 0)
            {
                fileData.CreatedBy = Constants.DefaultUser;
            }

            if (fileData.ModifiedBy < 0)
            {
                fileData.ModifiedBy = Constants.DefaultUser;
            }

            fileData.CreatedOn = DateTime.UtcNow;
            fileData.ModifiedOn = DateTime.UtcNow;

            var entity = new AgorusFile();
            entity.CopyFileData(fileData);

            var id = await _services.SaveAgorusFile(entity);
            return id;
        }

        [HttpGet("{ID}")]
        /// <summary>
        /// This API method is to retrieve a specific binary file.
        /// </summary>
        /// <param>None</param>
        public async Task<AgorusFileContent?> GetAgorusFile(int ID)
        {
            var result = await Task.Run(() =>
            {
                var results = from agorursFile in _dbContext.AgorusFiles
                                where agorursFile.ID == ID
                                select agorursFile;
                var retValue = results.FirstOrDefault();

                if (retValue != null)
                {
                    return retValue;
                }
                else
                {
                    return null;
                }
            });

            var dataFile = new AgorusFileContent();
            if (result != null)
            {
                dataFile.CopyFileData(result);
                dataFile.ID = result.ID;
            }
           
            return dataFile;
        }

        [HttpPut]
        /// <summary>
        /// This API method is to update a specific binary file.
        /// </summary>
        /// <param>None</param>
        public async Task<IActionResult> UpdateAgorusFile(AgorusFileContent fileData)
        {
            if (fileData == null || fileData.ID < 0)
            {
                return BadRequest();
            }

            var datFileFound = await _dbContext.AgorusFiles.FindAsync(fileData.ID);
            if (datFileFound == null)
            {
                return NotFound();
            }
       
            fileData.ModifiedOn = DateTime.UtcNow;
            datFileFound.CopyFileData(fileData);
            await _dbContext.SaveChangesAsync();

            return Ok();
        }

        [HttpDelete("{ID}")]
        /// <summary>
        /// This API method is to delete a specific binary file.
        /// </summary>
        /// <param>None</param>
        public async Task<IActionResult> DeleteAgorusFile(int ID)
        {
            var agorusFileFound = await _dbContext.AgorusFiles.FindAsync(ID);
            if (agorusFileFound == null)
            {
                return NotFound();
            }

            _dbContext.AgorusFiles.Remove(agorusFileFound);
            await _dbContext.SaveChangesAsync();

            return Ok();
        }
    }
}
